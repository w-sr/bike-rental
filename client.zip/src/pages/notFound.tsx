const NotFound = () => {
  return <>Not Found</>;
};

export default NotFound;
