export interface Context {
  isUserLogged?: boolean;
}
