export { default as bikeMutations } from "./mutations";
export { default as bikeQueries } from "./queries";
