export class AppConstants {
  public static readonly IS_USER_LOGGED = "isUserLogged";
}
